-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.23 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for student
CREATE DATABASE IF NOT EXISTS `student` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `student`;

-- Dumping structure for table student.class
CREATE TABLE IF NOT EXISTS `class` (
  `classid` int NOT NULL,
  `rollnumber` int NOT NULL,
  `studentid` int NOT NULL,
  UNIQUE KEY `classid_rollnumber` (`classid`,`rollnumber`),
  KEY `FK_studentid` (`studentid`),
  CONSTRAINT `FK_classid` FOREIGN KEY (`classid`) REFERENCES `masterclass` (`classid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_studentid` FOREIGN KEY (`studentid`) REFERENCES `studentdetails` (`studentid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table student.class: ~0 rows (approximately)
/*!40000 ALTER TABLE `class` DISABLE KEYS */;
INSERT INTO `class` (`classid`, `rollnumber`, `studentid`) VALUES
	(2, 1, 2),
	(2, 3, 3);
/*!40000 ALTER TABLE `class` ENABLE KEYS */;

-- Dumping structure for table student.masterclass
CREATE TABLE IF NOT EXISTS `masterclass` (
  `classid` int NOT NULL,
  `classname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table student.masterclass: ~4 rows (approximately)
/*!40000 ALTER TABLE `masterclass` DISABLE KEYS */;
INSERT INTO `masterclass` (`classid`, `classname`) VALUES
	(1, 'ONE'),
	(2, 'TWO'),
	(3, 'THREE'),
	(4, 'FOUR'),
	(5, 'FIVE');
/*!40000 ALTER TABLE `masterclass` ENABLE KEYS */;

-- Dumping structure for table student.mastersubject
CREATE TABLE IF NOT EXISTS `mastersubject` (
  `subjectid` int NOT NULL AUTO_INCREMENT,
  `subjectname` varchar(100) NOT NULL,
  PRIMARY KEY (`subjectid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table student.mastersubject: ~4 rows (approximately)
/*!40000 ALTER TABLE `mastersubject` DISABLE KEYS */;
INSERT INTO `mastersubject` (`subjectid`, `subjectname`) VALUES
	(1, 'Maths'),
	(2, 'Science'),
	(3, 'Hindi'),
	(4, 'English'),
	(5, 'Social Science');
/*!40000 ALTER TABLE `mastersubject` ENABLE KEYS */;

-- Dumping structure for table student.studentdetails
CREATE TABLE IF NOT EXISTS `studentdetails` (
  `studentid` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `emailid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`studentid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table student.studentdetails: ~0 rows (approximately)
/*!40000 ALTER TABLE `studentdetails` DISABLE KEYS */;
INSERT INTO `studentdetails` (`studentid`, `firstname`, `lastname`, `phonenumber`, `emailid`) VALUES
	(2, 'Lokesh', 'Khade', '9078897897', 'lk@gmail.com'),
	(3, 'Priya', 'Singh', '9797667788', 'ps@gmail.com');
/*!40000 ALTER TABLE `studentdetails` ENABLE KEYS */;

-- Dumping structure for table student.studentresult
CREATE TABLE IF NOT EXISTS `studentresult` (
  `studentid` int NOT NULL,
  `subjectid` int NOT NULL,
  `marksobtained` float NOT NULL,
  `totalmarks` float NOT NULL,
  UNIQUE KEY `studentid_subjectid` (`studentid`,`subjectid`),
  KEY `FK_studentresult_mastersubject` (`subjectid`),
  CONSTRAINT `FK_studentresult_mastersubject` FOREIGN KEY (`subjectid`) REFERENCES `mastersubject` (`subjectid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_studentresult_studentdetails` FOREIGN KEY (`studentid`) REFERENCES `studentdetails` (`studentid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table student.studentresult: ~0 rows (approximately)
/*!40000 ALTER TABLE `studentresult` DISABLE KEYS */;
INSERT INTO `studentresult` (`studentid`, `subjectid`, `marksobtained`, `totalmarks`) VALUES
	(3, 1, 89, 100),
	(3, 2, 90, 100),
	(3, 3, 79, 100),
	(3, 4, 89, 100),
	(3, 5, 56, 100);
/*!40000 ALTER TABLE `studentresult` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
