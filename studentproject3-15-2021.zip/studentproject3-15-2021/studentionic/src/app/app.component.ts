import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'StudentEntry', url: '/studententry', icon: 'apps' },
    { title: 'Class & RollNumber Entry', url: '/classdetailsentry', icon: 'apps' },
    { title: 'StudentList', url: '/studentlist', icon: 'list' },
    { title: 'Result Entry', url: '/studentresult', icon: 'albums' },
    { title: 'Print Marksheet', url: '/printmarksheet', icon: 'albums' }
  ];
  
  constructor() {}
}
