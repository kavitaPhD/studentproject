import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClassdetailsentryPage } from './classdetailsentry.page';

const routes: Routes = [
  {
    path: '',
    component: ClassdetailsentryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClassdetailsentryPageRoutingModule {}
