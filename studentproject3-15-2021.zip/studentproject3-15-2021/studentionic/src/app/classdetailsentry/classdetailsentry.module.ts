import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ClassdetailsentryPageRoutingModule } from './classdetailsentry-routing.module';

import { ClassdetailsentryPage } from './classdetailsentry.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    ClassdetailsentryPageRoutingModule
  ],
  declarations: [ClassdetailsentryPage]
})
export class ClassdetailsentryPageModule {}
