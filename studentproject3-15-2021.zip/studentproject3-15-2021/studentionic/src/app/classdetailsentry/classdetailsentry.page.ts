import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentService } from 'src/app/services/student.service';

@Component({
  selector: 'app-classdetailsentry',
  templateUrl: './classdetailsentry.page.html',
  styleUrls: ['./classdetailsentry.page.scss'],
})
export class ClassdetailsentryPage implements OnInit {

  public studentlist :  any = [];
  public class : any = [];
  entryClass : FormGroup;
  constructor(private fb : FormBuilder, private studentservice : StudentService) { 

  } 

  ngOnInit() {

    this.getClass();
    this.create();
    
  }

  create()
  {
      this.entryClass = this.fb.group({ 
      studentid : [''],    
      rollnumber : [''],
      classid : []
    })
  }

  getStudentByid(id :any)
  {
    this.studentservice.getDetailsforclassByID(id).subscribe(res => {
     
    if (res[0]) {
      this.studentlist = res;
      
    } else {
      this.studentservice.toast("Student Id not exist");
    }
   });
  }

  getClass()
  {
    this.studentservice.getClass().subscribe(res => {
    this.class = res;  
   });
  }

  save()
  {
    console.log(this.entryClass.value);
    this.studentservice.saveclass(this.entryClass.value).subscribe(res => {
      if (res['affectedRows']) {
        this.create();
        this.studentservice.toast("Inserted Successfully");
      } else {
        this.studentservice.toast("Something wrong");
      }

         
   });
  }

}
