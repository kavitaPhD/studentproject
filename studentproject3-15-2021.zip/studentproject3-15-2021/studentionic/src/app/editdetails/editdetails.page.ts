import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from 'src/app/services/student.service';

@Component({
  selector: 'app-editdetails',
  templateUrl: './editdetails.page.html',
  styleUrls: ['./editdetails.page.scss'],
})
export class EditdetailsPage implements OnInit {
  id: any;
  editForm : FormGroup;
  constructor(private activatedRoute : ActivatedRoute, private router : Router, private fb : FormBuilder, private studentservice : StudentService) { }

  ngOnInit() {
    
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    console.log(this.id);
    this.createForm();

    this.studentservice.getDetailsByID(this.id).subscribe(res => {
      this.editForm.patchValue({
        studentid : [this.id],
        firstname: [res[0].firstname],
        lastname: [res[0].lastname],
        phonenumber: [res[0].phonenumber],
        emailid: [res[0].emailid]
      });
    });
  }

  createForm()
  {
    this.editForm = this.fb.group({
      studentid : [''],
      firstname : ['',Validators.required],
      lastname : ['',Validators.required],
      phonenumber : ['',[Validators.required,Validators.pattern('^[6-9]{1}[0-9]{9}$')]],
      emailid : ['',[Validators.required,Validators.email]]
    })
  }

  isValidInput(fieldName: any): boolean {
    return this.editForm.controls[fieldName].invalid &&
      (this.editForm.controls[fieldName].dirty || this.editForm.controls[fieldName].touched);
  }

  update() {
    this.studentservice.update(this.editForm.value).subscribe(res => {
      if (res['affectedRows']) {
        this.createForm();
        this.studentservice.toast("Updated Successfully");
      } else {
        this.studentservice.toast("Something wrong");
      }    
    })
  }

}
