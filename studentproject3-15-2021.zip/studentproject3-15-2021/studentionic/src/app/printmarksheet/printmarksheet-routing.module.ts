import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PrintmarksheetPage } from './printmarksheet.page';

const routes: Routes = [
  {
    path: '',
    component: PrintmarksheetPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PrintmarksheetPageRoutingModule {}
