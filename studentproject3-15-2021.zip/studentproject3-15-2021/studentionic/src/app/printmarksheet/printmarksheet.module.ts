import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PrintmarksheetPageRoutingModule } from './printmarksheet-routing.module';

import { PrintmarksheetPage } from './printmarksheet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PrintmarksheetPageRoutingModule
  ],
  declarations: [PrintmarksheetPage]
})
export class PrintmarksheetPageModule {}
