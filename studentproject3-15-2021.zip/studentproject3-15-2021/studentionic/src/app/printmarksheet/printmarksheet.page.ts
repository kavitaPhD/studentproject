import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
@Component({
  selector: 'app-printmarksheet',
  templateUrl: './printmarksheet.page.html',
  styleUrls: ['./printmarksheet.page.scss'],
})
export class PrintmarksheetPage implements OnInit {

  constructor(private studentservice : StudentService ) { }

  ngOnInit() {
  }
  printmarksheet(id :any)
  {
    location.origin
    let link = 'http://localhost:3000' + '/student/printmarksheet/' + id;
    window.open(link, "_blank");
  }
}
