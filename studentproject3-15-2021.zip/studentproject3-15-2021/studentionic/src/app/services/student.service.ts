import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AlertController, ToastController } from '@ionic/angular';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http : HttpClient,private toastController: ToastController,private alertController: AlertController) { }
  toast(msg: any): void {
    let toast = this.toastController.create({
      message: msg,
      duration: 3000,
      position: 'middle'
    });
    toast.then(toast => toast.present());
  }
  showAlert(msg: any) {
    let alert = this.alertController.create({
      message: msg,
      header: 'Error',
      buttons: ['OK']
    });
    alert.then(alert => alert.present());
  }
  save(data: any) {
    
    return this.http.post('http://localhost:3000' + '/student/insert', data).pipe(tap(res => { res }),
      catchError(e => {
        
        throw new Error(e);
      })
    );
  }

  saveclass(data: any) {
    console.log(data);
    return this.http.post('http://localhost:3000' + '/student/insertclasswithsid', data).pipe(tap(res => { res }),
      catchError(e => {
        
        throw new Error(e);
      })
    );
  }

  savemarks(data: any) {
    console.log(data);
    return this.http.post('http://localhost:3000' + '/student/insertmarks', data).pipe(tap(res => { res }),
      catchError(e => {
        
        throw new Error(e);
      })
    );
  }

  getClass() {
      return this.http.get('http://localhost:3000' + '/student/class').pipe(tap(res => { res
      }),
      catchError(e => {        
        throw new Error(e);
      })
    );
  }

  getSubject() {
    return this.http.get('http://localhost:3000' + '/student/subject').pipe(tap(res => { res
    }),
    catchError(e => {        
      throw new Error(e);
    })
  );
  }

  getStudentList() {
    return this.http.get('http://localhost:3000' + '/student/studentlist').pipe(tap(res => { res
    }),
    catchError(e => {        
      throw new Error(e);
    })
  );
}

getDetailsByID(id: any) {
  return this.http.get('http://localhost:3000' + '/student/studentdetailsbyid/' + id).pipe(tap(res => { res }),
    catchError(e => {
    throw new Error(e);
    })
  );
}

getDetailsforclassByID(id: any) {
  return this.http.get('http://localhost:3000' + '/student/studentdetailsforclassbyid/' + id).pipe(tap(res => { res }),
    catchError(e => {
    throw new Error(e);
    })
  );
}

getMarksList() {
  return this.http.get('http://localhost:3000' + '/student/markslist').pipe(tap(res => { res }),
    catchError(e => {
    throw new Error(e);
    })
  );
}

update(data: any) {
  return this.http.put('http://localhost:3000' + '/student/update/', data).pipe(tap(res => { res }),
    catchError(e => {
       throw new Error(e);
    })
  );
}

delete(id: any) {
  return this.http.delete('http://localhost:3000' + '/student/delete/' + id).pipe(tap(res => { res }),
    catchError(e => {
        throw new Error(e);
    })
  );
}
printmarksheet(id : any){
  return this.http.get('http://localhost:3000' + '/student/printmarksheet/' + id).pipe(tap(res => { res }),
    catchError(e => {
    throw new Error(e);
    })
  );
}

}
