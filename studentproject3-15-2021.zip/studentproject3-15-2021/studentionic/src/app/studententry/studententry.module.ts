import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StudententryPageRoutingModule } from './studententry-routing.module';

import { StudententryPage } from './studententry.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    StudententryPageRoutingModule
  ],
  declarations: [StudententryPage]
})
export class StudententryPageModule {}
