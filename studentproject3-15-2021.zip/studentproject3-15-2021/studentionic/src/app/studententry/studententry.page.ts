import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentService } from 'src/app/services/student.service';

@Component({
  selector: 'app-studententry',
  templateUrl: './studententry.page.html',
  styleUrls: ['./studententry.page.scss'],
})
export class StudententryPage implements OnInit {

  entryForm : FormGroup;

  public class : any = [];
  constructor(private fb : FormBuilder, private studentservice : StudentService) { }

  ngOnInit() {

    this.create();   
  }

  create()
  {
      this.entryForm = this.fb.group({
      firstname : ['',Validators.required],
      lastname : ['',Validators.required],
      phonenumber : ['',[Validators.required,Validators.pattern('^[6-9]{1}[0-9]{9}$')]],
      emailid : ['',[Validators.required,Validators.email]]
    })
  }
  
  isValidInput(fieldName: any): boolean {
    return this.entryForm.controls[fieldName].invalid &&
      (this.entryForm.controls[fieldName].dirty || this.entryForm.controls[fieldName].touched);
  }

  save()
  {
    
    this.studentservice.save(this.entryForm.value).subscribe(res => {
      console.log(res);
      if (res) {
        this.create();
        this.studentservice.toast("Inserted Successfully with Student Id :" +res + ". Enter class details with this student id");
      } else {
        this.studentservice.toast("Something wrong");
      }

         
   });
  }

}
