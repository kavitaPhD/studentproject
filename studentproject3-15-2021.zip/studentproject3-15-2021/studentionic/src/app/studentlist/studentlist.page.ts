import { Component, OnInit } from '@angular/core';
import { StudentService  } from 'src/app/services/student.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.page.html',
  styleUrls: ['./studentlist.page.scss'],
})
export class StudentlistPage implements OnInit {

  public studentlist :  any = [];

  constructor(private studentservice : StudentService, private router : Router,public alertController: AlertController) { }

  ngOnInit() {

    this.getStudentList();

  }

 getStudentList()
  {
    this.studentservice.getStudentList().subscribe(res => {
    this.studentlist = res;  
   });
  }

  edit(id: any) {
   
    this.router.navigate(['editdetails/' + id]);
  }

  async delete(id: any) {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Confirm!',
      message: 'Are you sure to delete!!!',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Delete',
          handler: () => {
            this.studentservice.delete(id).subscribe(res => {
              if (res['affectedRows']) {
                this.getStudentList();
                this.studentservice.toast("Deleted Successfully");
              } else {
                this.studentservice.toast("Something wrong");
              }
            })
          }
        }
      ]
    });

    await alert.present();
  }

}
