import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StudentresultPageRoutingModule } from './studentresult-routing.module';

import { StudentresultPage } from './studentresult.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    StudentresultPageRoutingModule
  ],
  declarations: [StudentresultPage]
})
export class StudentresultPageModule {}
