import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { StudentService  } from 'src/app/services/student.service';

@Component({
  selector: 'app-studentresult',
  templateUrl: './studentresult.page.html',
  styleUrls: ['./studentresult.page.scss'],
})
export class StudentresultPage implements OnInit {

  resultForm : FormGroup;
  public studentlist :  any = [];
  public markslist :  any = [];
 public subject :  any = [];

 public class : any = [];
   /*{
     classid : 1,
     classname : 'ONE',
   },
   {
    classid : 2,
    classname : 'TWO',
  },
 ]*/

  constructor(private fb : FormBuilder, private studentservice : StudentService) { }

  ngOnInit() {

    
    this.getSubject();
    this.create();   
    
  }

  create()
  {
      this.resultForm = this.fb.group({
      studentid : [''],
      classid : [],
      subjectid : [],
      totalmarks : ['',Validators.required],
      marksobtained : ['',Validators.required]
    })
  }

  isValidInput(fieldName: any): boolean {
    return this.resultForm.controls[fieldName].invalid &&
      (this.resultForm.controls[fieldName].dirty || this.resultForm.controls[fieldName].touched);
  }

  save()
  {
    console.log(this.resultForm.value);
    this.studentservice.savemarks(this.resultForm.value).subscribe(res => {
      if (res['affectedRows']) {
        console.log(res);
        this.create();
        this.getMarksList();
        this.studentservice.toast("Inserted Successfully");
        
      } else {
        this.studentservice.toast("Something wrong");
      }
   });
  }

  getMarksList()
  {
    this.studentservice.getMarksList().subscribe(res => {
    this.markslist = res;  
   });
  }

  getSubject()
  {
    this.studentservice.getSubject().subscribe(res => {
    this.subject = res;  
    
   });
  }
  getStudentByid(id :any)
  {
    this.studentservice.getDetailsByID(id).subscribe(res => {
     
    if (res[0]) {
      this.studentlist = res;
      this.getMarksList();
      
    } else {
      this.studentservice.toast("Student Id not exist");
    }
   });
  }

  check(){
    if(this.resultForm.get('totalmarks').value){
      if(+this.resultForm.get('totalmarks').value < +this.resultForm.get('marksobtained').value)
      {
        this.resultForm.patchValue({
          marksobtained : ''
        });
        this.studentservice.toast("Marks obtain can not be grather than Total Marks");
      }
    }
  }

}
