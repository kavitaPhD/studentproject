var mysql = require('mysql');
var connection = mysql.createPool({
   host: 'localhost',
   user: 'root',
   password: 'redhat',
   database: 'student',
   multipleStatements: true
});
module.exports = connection;

