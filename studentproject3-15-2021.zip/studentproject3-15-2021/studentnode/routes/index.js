var express = require('express');
var router = express.Router();
var html_to_pdf = require('html-pdf-node');
/* GET home page. */
router.get('/', function(req, res, next) {
  console.log('pop')
  let options = { format: 'A4' };
// Example of options with args //
// let options = { format: 'A4', args: ['--no-sandbox', '--disable-setuid-sandbox'] };

let file = { content: "<h1>Welcome to html-pdf-node</h1>" };
// or //
//let file = { url: "https://agrikosh.cg.nic.in" };
html_to_pdf.generatePdf(file, options).then(pdfBuffer => {
  console.log("PDF Buffer:-", pdfBuffer);
});
});

module.exports = router;
