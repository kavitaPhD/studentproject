var express = require('express');
var router = express.Router();
var db = require('../dbconnection');
var fs = require('fs');
var pdf = require('html-pdf');
/* GET users listing. */
router.get('/class', function(req, res, next) {
    db.query('select * from masterclass',function(error,results,field)
    {if (error) throw error;
     res.json(results);
    } )
  
});

router.get('/subject', function(req, res, next) {
    db.query('select * from mastersubject',function(error,results,field)
    {if (error) throw error;
     res.json(results);
    } )
  
});

router.post('/insert',function(req,res,next){
   
    console.log(req.body);
    var data=req.body;
    db.query('INSERT INTO studentdetails(firstname, lastname,phonenumber,emailid) VALUES (?,?,?,?)', [ data.firstname, data.lastname,data.phonenumber,data.emailid ], function (error, results, fields) {
        if (error) throw error;
        res.json(results.insertId);
       console.log('The solution is: ', results[0]);
      });      
})

router.post('/insertclasswithsid',function(req,res,next){
   
    console.log(req.body);
    var data=req.body;
    db.query('INSERT INTO class(studentid,classid,rollnumber) VALUES (?, ?,?)', [ data.studentid, data.classid,data.rollnumber], function (error, results, fields) {
        if (error) throw error;
        res.json(results);
       // console.log('The solution is: ', results[0]);
      });
})

router.post('/insertmarks',function(req,res,next){
   
    console.log(req.body);
    var data=req.body;
    db.query('INSERT INTO studentresult(studentid,subjectid,totalmarks,marksobtained) VALUES (?, ?,?,?)', [ data.studentid, data.subjectid,data.totalmarks,data.marksobtained,data.classid ], function (error, results, fields) {
        if (error) throw error;
        res.json(results);
       // console.log('The solution is: ', results[0]);
      });
})

router.get('/studentlist', function(req, res, next) {
    db.query(`SELECT studentdetails.studentid, studentdetails.firstname, studentdetails.lastname,
    class.rollnumber, studentdetails.phonenumber, studentdetails.emailid,
    masterclass.classname FROM studentdetails
    inner JOIN class ON studentdetails.studentid=class.studentid 
    INNER JOIN masterclass ON masterclass.classid = class.classid`,function(error,results,field)
    {if (error) throw error;
     res.json(results);
    } )
  
});

router.get('/markslist', function(req, res, next) {
    db.query(`SELECT mastersubject.subjectname, studentresult.totalmarks,studentresult.marksobtained  
    FROM studentresult
    inner JOIN mastersubject ON studentresult.subjectid=mastersubject.subjectid`,function(error,results,field)
    {if (error) throw error;
     res.json(results);
    } )
  
});


router.get('/studentdetailsbyid/:id', function(req, res, next) {
    var id = req.params.id;
    db.query(`SELECT studentdetails.studentid, studentdetails.firstname, studentdetails.lastname,
    class.rollnumber, studentdetails.phonenumber, studentdetails.emailid,
    masterclass.classname FROM studentdetails
    inner JOIN class ON studentdetails.studentid=class.studentid 
    INNER JOIN masterclass ON masterclass.classid = class.classid
    WHERE studentdetails.studentid = ?`, [id],function(error,results,field)
    {if (error) throw error;
     res.json(results);
    } )
  
});

router.get('/studentdetailsforclassbyid/:id', function(req, res, next) {
    console.log(req.params.id);
    var id = req.params.id;
    db.query('SELECT * from studentdetails WHERE studentid=?',[id],function(error,results,field)
    {if (error) throw error;
     res.json(results);
    } )  
});

router.put('/update',function(req,res,next){
   
    console.log(req.body);
    var data=req.body;
    db.query('UPDATE studentdetails SET firstname=?,lastname=?,phonenumber=?,emailid=? WHERE studentid=?', [data.firstname, data.lastname, data.phonenumber,data.emailid, data.studentid], function (error, results, fields) {
        if (error) throw error;
        res.json(results);
       // console.log('The solution is: ', results[0]);
      });
})

router.delete('/delete/:id', function (req, res) {
    console.log(req.body);
    var id = req.params.id;
    db.query('delete from studentdetails where studentid=?', [id],function (error, results, fields) {
        if (error) throw error;
        res.json(results);
       // console.log('The solution is: ', results[0]);
      });
});

router.get('/printmarksheet/:id', function (req, res) {
    var id = req.params.id;
    console.log(id);
    db.query(`SELECT studentdetails.studentid, studentdetails.firstname, studentdetails.lastname,
    class.rollnumber, studentdetails.phonenumber, studentdetails.emailid,
    masterclass.classname,mastersubject.subjectname,studentresult.marksobtained,studentresult.totalmarks
    FROM studentdetails inner JOIN studentresult ON studentdetails.studentid=studentresult.studentid 
    INNER JOIN class ON studentdetails.studentid = class.studentid
    INNER JOIN masterclass ON masterclass.classid = class.classid
    INNER JOIN mastersubject ON mastersubject.subjectid = studentresult.subjectid WHERE studentdetails.studentid=?`, [id],function (error, results, fields) {
        if (error) throw error;
      //  res.json(results);
      let data = results[0];
      console.log(data);
      let html =`<head>
      <style type="text/css">
          @media print {
              html,
              body {
                  margin: 10;
                  padding: 0;
              }
              table,
              td,
              th {
                  border-style: solid;
                  border-width: 0px;
                  font-size: 25px !important;
                  border-collapse: collapse;
                  text-align: left;
              }
              table {
                  width: 100%;
              }
  
              ol {
                  font-size: 10px;
              }
  
              #footer {
                  position: fixed;
                  bottom: 0;
                  right: 0;
                  text-align: center;
                  font-size: 10px;
              }
      </style>
  </head>
  <body>
      <center>
          <h1>Result of Final Exam</h1>
      </center>
      <hr>
      <table>
          <tr>
              <td width="50%"><b>Class:</b> `+ data.classname + `</td>
              <td width="25%"><b>Student ID:</b> `+ data.studentid +  `</td>
              <td width="25%"><b>Roll Number :</b> `+ data.rollnumber + `</td>
          </tr>
          <tr>
              <td width="50%" colspan="2"><b>Student Name:</b> `+ data.firstname + ' ' + data.lastname + `</td>
              <td width="50%" colspan="2"><b>Annual Year.:</b> 2021-2022</td>
          </tr>
         
          <tr>
              <td width="50%" colspan="2"><b></b></td>
              <td width="50%" colspan="2"></td>
          </tr>
          <table style="width:100%;">
          <tr>
            <th width="25%"><b>Subject</b></th>
            <th width="25%"><b>Total Marks</b></th>
            <th width="25%"><b>Marks Obtained</b></th>
            <th width="25%"><b>Remarks</b></th>
          </tr>`;
          var Marks = 0;
          var TMarks = 0;
          var remark;
          var percentage = 0;
          var result = 0;
        results.forEach((element) => {
            Marks = Marks + element.marksobtained;
            TMarks = TMarks + element.totalmarks;
            if (element.marksobtained >= 75)
            {
                remark = 'Distinction';    
            }
            else{
                remark = ''; 
            }
            html +=
            ` <tr>
                <td width="25%"><strong>` +
            element.subjectname +
            `</strong></td>
                <td width="25%">` +
            element.totalmarks +
            `</td>
            <td width="25%">` +
            element.marksobtained +
            `</td>
            <td width="25%">` + remark  + `</td>
            </tr>`;
        });
        percentage = (Marks/TMarks)*100;
        var par = percentage.toFixed(2);
        if (par >= 33)
            {
                result = 'Pass';    
            }
            else
            {
                result = 'Fail'; 
            }
        html +=
          `</table> 
          <table>     
          <tr>
              <td width="25%" colspan="2"><b>Total:</b></td> 
              <td width="25%"><b>` + TMarks +  `</b></td>
              <td width="25%"><b>` + Marks +  `</b></td>
              <td width="25%" colspan="2"></td>  
          </tr> 
          
          <tr>
          
              <td width="25%" colspan="2"><b>Percentage : </b></td>  
              <td width="25%"><b>` + par +  `</b> %</td>           
          </tr> 
          <tr>
              <td width="25%" colspan="2"><b>Result : </b></td>
              <td width="25%"><b>` + result +  `</b> </td> 
          </tr> 
          </table>      
      </table>
      </body> `;

 

      var options = { format: 'Letter' };
       
      pdf.create(html, options).toStream((err, stream) => {
        if (err) return res.end(err.stack);
        res.setHeader("Content-type", "application/pdf");
        stream.pipe(res);
      });
      
       console.log(results[0].firstname);
      });
});

module.exports = router;