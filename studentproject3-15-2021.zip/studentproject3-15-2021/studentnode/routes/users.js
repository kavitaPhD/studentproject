var express = require('express');
var router = express.Router();
var fs = require('fs');
var pdf = require('html-pdf');
/* GET users listing. */
router.get('/', function(req, res, next) {
  
//var html = fs.readFileSync('./test/businesscard.html', 'utf8');
let html ='<head> <h1>My First Heading</h1> </head> <table style="width:100%"> <tr> <th>Firstname</th> <th>Lastname</th> </tr> </table>';

 

var options = { format: 'Letter' };
 
pdf.create(html, options).toStream((err, stream) => {
  if (err) return res.end(err.stack);
  res.setHeader("Content-type", "application/pdf");
  stream.pipe(res);
});


});

module.exports = router;
